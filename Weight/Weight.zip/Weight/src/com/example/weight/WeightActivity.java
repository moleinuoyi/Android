package com.example.weight;

import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.format.Formatter;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewConfiguration;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.Toast;

public class WeightActivity extends Activity {
	
	public static SeekBar seekbar;
	
	public static TextView time_left;
	public static TextView time_right;
	
	private double sex;
	private String str_height;
	private String str_weight;
	private EditText et;
	private EditText etw;
	private Button start;
	private Button stop;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);/* ����main.xml Layout */
		
		time_left=(TextView)findViewById(R.id.time_tv1);
		time_right = (TextView)findViewById(R.id.time_tv2);
		seekbar = (SeekBar)findViewById(R.id.player_seekbar);
		
		Button button1=(Button) findViewById(R.id.btn_calculate);
		et = (EditText) findViewById(R.id.et_height);
		etw = (EditText) findViewById(R.id.et_weight);
		
		button1.setOnClickListener(new OnClickListener(){ //button1�ļ�����
			@Override
			public void onClick(View v){			
//			RadioGroup radio=(RadioGroup) findViewById(R.id.rg_sex);
			
			
				str_height = et.getText().toString();
				str_weight = etw.getText().toString();
				if (str_height.equals("")) {
                    Toast.makeText(WeightActivity.this, "���߲���Ϊ��", Toast.LENGTH_SHORT).show();
                    return;
                }
				for(int i=0;i<str_height.length();i++){
					if(str_height.charAt(i)>'9' || str_height.charAt(i)<'0'){
						Toast.makeText(WeightActivity.this, "���߲���Ϊ���������ַ�", Toast.LENGTH_SHORT).show();
						et.setText("");
						return;
					}
				}
				
				if (str_weight.equals("")) {
                    Toast.makeText(WeightActivity.this, "���ز���Ϊ��", Toast.LENGTH_SHORT).show();
                    return;
                }
				for(int i=0;i<str_weight.length();i++){
					if(str_weight.charAt(i)>'9' || str_weight.charAt(i)<'0'){
						Toast.makeText(WeightActivity.this, "���ز���Ϊ���������ַ�", Toast.LENGTH_SHORT).show();
						etw.setText("");
						return;
					}
				}
				
				double height = Double.parseDouble(str_height);//��stringת����duoble
				double weight = Double.parseDouble(str_weight);
				/*
				radio.setOnCheckedChangeListener(new OnCheckedChangeListener(){
					RadioButton rb1=(RadioButton) findViewById(R.id.rb_male);
					RadioButton rb2=(RadioButton) findViewById(R.id.rb_female);
					public void onCheckedChanged(RadioGroup arg0,int checkedId){					
						RadioButton rb1=(RadioButton) findViewById(R.id.rb_male);
						RadioButton rb2=(RadioButton) findViewById(R.id.rb_female);
						if (rb1.isSelected()) {
                            sex = "M";
                        } else if(rb2.isSelected()){
                            sex = "F";
                        }
						Log.i("zhouweizhi<<<<", sex);
					}
				});*/
				RadioButton rb1=(RadioButton) findViewById(R.id.rb_male);
				RadioButton rb2=(RadioButton) findViewById(R.id.rb_female);
				if (rb1.isChecked()) {
                    sex = 1;
                } else if(rb2.isChecked()){
                    sex = 2;
                }
				//Log.i("zhouweizhi<<<<", sex);
				
				
				Intent it=new Intent();
				it.setClass(WeightActivity.this, ResultActivity.class);
				Bundle bundle=new Bundle();
				bundle.putDouble("height", height);
				bundle.putDouble("weight", weight);
				bundle.putDouble("sex",sex);
				
				it.putExtras(bundle);
				startActivity(it);
				WeightActivity.this.finish();
			}
		});
		
		start = (Button) findViewById(R.id.btn_play);
		stop = (Button) findViewById(R.id.btn_stop);
		//����������ֹͣService�����intent
		final Intent it = new Intent("android.zhang.service.playmusic");
		
		start.setEnabled(true);
		stop.setEnabled(false);
		
		start.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				// TODO �Զ����ɵķ������
				start.setEnabled(false);
				stop.setEnabled(true);
				startService(it);
			}			
		});
		
		stop.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				// TODO �Զ����ɵķ������
				start.setEnabled(true);
				stop.setEnabled(false);
				stopService(it);
			}		
		});
		
		try{
			ViewConfiguration mconfig = ViewConfiguration.get(this);
			Field menuKeyField;
			menuKeyField = ViewConfiguration.class.getDeclaredField("sHasPermanentMenuKey");
			if(menuKeyField != null){
				menuKeyField.setAccessible(true);
				menuKeyField.setBoolean(mconfig, false);
			}
		}catch(NoSuchFieldException e){
			e.printStackTrace();		
		}catch(IllegalAccessException e){
			e.printStackTrace();
		}catch(IllegalArgumentException e){
			e.printStackTrace();
		}
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu){
		MenuInflater inflater=getMenuInflater();
		inflater.inflate(R.menu.weight, menu);
		return super.onCreateOptionsMenu(menu);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item){
		switch (item.getItemId()){
		case R.id.action_calendar:
			SimpleDateFormat format = new SimpleDateFormat("yyyy��mm��dd��HH:mm:ss");
			Date curDate = new Date(System.currentTimeMillis());
			String str = format.format(curDate);
			Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
			break;
		case R.id.action_call:
			Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:18925207830"));
			startActivity(intent);
			break;
		case R.id.action_msm:
			SmsManager smsManager = SmsManager.getDefault();
			smsManager.sendTextMessage("10086", null, "10086", null, null);
		}
		return super.onOptionsItemSelected(item);
	}
}
