package com.example.weight;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;

public class PlayMusicService extends Service{
	
	public static MediaPlayer mMediaPlayer;
	public static int playing_id = 0;
	
	@Override
	public IBinder onBind(Intent intent) {
		// TODO �Զ����ɵķ������
		return null;
	}
	@Override
	public void onStart(Intent intent,int startId){
		super.onStart(intent, startId);
		mMediaPlayer = MediaPlayer.create(this, R.raw.sugar);
		mMediaPlayer.start();
	}
	@Override
	public void onDestroy()
	{
		super.onDestroy();
		//ֹͣ��������
		mMediaPlayer.stop();
	}
}
