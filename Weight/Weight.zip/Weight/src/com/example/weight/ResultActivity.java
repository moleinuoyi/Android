package com.example.weight;

import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class ResultActivity extends Activity{
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.result);
		Bundle bundle=this.getIntent().getExtras();
		Double sex= bundle.getDouble("sex");
		Double height=bundle.getDouble("height");
		Double weight1=bundle.getDouble("weight");
		double IBM;
		String ibm;
		double hm=height/100;
		
		String sexText="";
		if(sex == 1)
			sexText="����";
		else if(sex == 2)
			sexText="Ů��";
		else
			sexText="������";
		String weight=this.getWeight(sex,height);
		TextView tv=(TextView) findViewById(R.id.text1);
		String str="����һλ"+sexText+"\n��������ǣ�"+height+"����\n��������ǣ�"+weight1+"����\n��ı�׼�����ǣ�"+weight+"����";
		IBM=weight1/(hm*hm);
		ibm=format(weight1/(hm*hm));
		str+="\n���IBMֵΪ��"+ibm;
		if(IBM<18.5){
			str+="���IBMֵС��18.5�����س��ᣬ����������ʳ����ǿ������";
		}else if(IBM<24){
			str+="�����������������Χ�����鱣����ʳ���⣬�������֣�";
		}else if(IBM<28){
			str+="���IBMֵ����24�����س��أ����������ʳ����ǿ������";
		}else{
			str+="���IBMֵ����28�����ڷ��֣����顣������";
		}
		tv.setText(str);			
		Button button2=(Button) findViewById(R.id.btn_return);
		button2.setOnClickListener(new OnClickListener(){
			public void onClick(View arg0) {   
                Intent intent = new Intent();    
                intent.setClass(ResultActivity.this, WeightActivity.class);  
                startActivity(intent);  
                ResultActivity.this.finish(); 
			}
		});
		
		try{
			ViewConfiguration mconfig = ViewConfiguration.get(this);
			Field menuKeyField;
			menuKeyField = ViewConfiguration.class.getDeclaredField("sHasPermanentMenuKey");
			if(menuKeyField != null){
				menuKeyField.setAccessible(true);
				menuKeyField.setBoolean(mconfig, false);
			}
		}catch(NoSuchFieldException e){
			e.printStackTrace();		
		}catch(IllegalAccessException e){
			e.printStackTrace();
		}catch(IllegalArgumentException e){
			e.printStackTrace();
		}
	
	}
	
	private String format(double num){
		NumberFormat formatter=new DecimalFormat("0.00");
		String s=formatter.format(num);
		return s;
	}
	
	private String getWeight(Double sex,double height){
		String weight="";
		if(sex == 1)
			weight=format((height-80)*0.7);
		else if(sex == 2)
			weight=format((height-70)*0.6);
		else weight="0";
		return weight;
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu){
		MenuInflater inflater=getMenuInflater();
		inflater.inflate(R.menu.weight, menu);
		return super.onCreateOptionsMenu(menu);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item){
		switch (item.getItemId()){
		case R.id.action_calendar:
			SimpleDateFormat format = new SimpleDateFormat("yyyy��mm��dd��HH:mm:ss");
			Date curDate = new Date(System.currentTimeMillis());
			String str = format.format(curDate);
			Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
			break;
		case R.id.action_call:
			Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:18925207830"));
			startActivity(intent);
			break;
		case R.id.action_msm:
			SmsManager smsManager = SmsManager.getDefault();
			smsManager.sendTextMessage("10086", null, "10086", null, null);
		}
		return super.onOptionsItemSelected(item);
	}
	
}
