package com.example.submenu;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;

public class MenuSUB extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		SubMenu sub=menu.addSubMenu(R.string.title);
		sub.add(0,1,1,R.string.local);
		sub.add(0,1,1,R.string.online);
		return super.onCreateOptionsMenu(menu);
	}

}
