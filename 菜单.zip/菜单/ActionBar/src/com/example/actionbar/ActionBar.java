package com.example.actionbar;

import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.ViewConfiguration;
import android.widget.Toast;

public class ActionBar extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		try{
			//
			ViewConfiguration mconfig = ViewConfiguration.get(this);
			Field menuKeyField;
			menuKeyField= ViewConfiguration.class.getDeclaredField("sHasPermanentMenukey");
			if(menuKeyField != null){
				menuKeyField.setAccessible(true);
				menuKeyField.setBoolean(mconfig, false);
			}
		}catch(NoSuchFieldException e){
			e.printStackTrace();
		}catch(IllegalAccessException e){
			e.printStackTrace();
		}catch(IllegalArgumentException e){
			e.printStackTrace();
		}
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu){
		MenuInflater inflater=getMenuInflater();
		inflater.inflate(R.menu.action_bar, menu);
		return super.onCreateOptionsMenu(menu);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		switch(item.getItemId()){
		case R.id.action_calendar:
			SimpleDateFormat formatter = new SimpleDateFormat("yyy��MM��dd��HH:mm:ss");
			Date curDate = new Date(System.currentTimeMillis());
			String str = formatter.format(curDate);
			Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
			break;
		case R.id.action_call:
			Intent intent = new Intent(Intent.ACTION_CALL,Uri.parse("tel:10086"));
			startActivity(intent);
			break;
		case R.id.action_msm:
			SmsManager smsManager = SmsManager.getDefault();
			smsManager.sendTextMessage("10086", null, "10086", null, null);
			
		}
		return super.onOptionsItemSelected(item);
	}
	
	
}
